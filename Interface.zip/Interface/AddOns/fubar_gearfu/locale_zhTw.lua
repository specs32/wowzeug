local L = Rock("LibRockLocale-1.0"):GetTranslationNamespace("FuBar_GearFu")
L = LibStub("AceLocale-3.0"):NewLocale('FuBar_GearFu', 'zhTw', false);

if L then
	L["Chat"] = "頻道";
	L["Colors"] = "顏色";
	L["Default color"] = "預設顏色";
	L["FuBar title"] = "FuBar 標題";
	L["GearFu"] = "GearFu";
	L["General"] = "普通";
	L["Icon Size"] = "圖示尺寸";
end;
