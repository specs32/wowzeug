GearFu	= LibStub('AceAddon-3.0'):NewAddon('FuBar_GearFu', 'LibFuBarPlugin-3.0', 'AceEvent-3.0');
local L	= LibStub('AceLocale-3.0'):GetLocale('FuBar_GearFu', false);	-- not silent for now, while we're debugging
local T	= AceLibrary('Tablet-2.0');


function GearFu:OnUpdateFuBarText()
    self:SetFuBarText('GearFu');
end;

GearFu:SetFuBarOption('tooltipType', 'Tablet-2.0');
GearFu:SetFuBarOption('clickableTooltip', true);
GearFu:SetFuBarOption('configType', 'AceConfigDialog-3.0');

GearFu.sets = {}
GearFu.title = L['GearFu']..' - '..L["Equipment Manager ++"];
-- GearFu.name = 'FuBar_GearFu';

function GearFu:updateTitle()
	local gearfu_text = '';
	if(self.db.profile.showGearFuTitle) then
		gearfu_text = L["GearFu"];
	end;
	
	local icon = '';
	if(self.db.profile.showCurrentSetIcon and self.sets[self.currentSet]) then
		icon = '|T'..self.sets[self.currentSet].icon..':16|t ';
	end;
	
	if self.db.profile.showSetInTitle then
		if self.currentSet == 0 then
			self:SetFuBarText(gearfu_text..' ('..icon..'|c'..self:RGB2Hex(self.db.profile.colors.title.set)..L['unknown set']..'|r)');
		else
			self:SetFuBarText(gearfu_text..' ('..icon..'|c'..self:RGB2Hex(self.db.profile.colors.title.set)..GearFu.sets[GearFu.currentSet].name..'|r)');
		end;
	else
		if(self.db.profile.showGearFuTitle) then
			self:SetFuBarText(gearfu_text);
		else
			-- try to set the icon ?
			self:SetFuBarText('|T'..self.sets[self.currentSet].icon..':16|t');
		end;
	end;

end;

function GearFu:reIndexSets()
	self.sets = {}
	for i = 1, GetNumEquipmentSets() do
		local name, texture = GetEquipmentSetInfo(i);
		self.sets[i] = {
			icon = texture,
			name = name,
		}
	end;
end;

function GearFu:OnInitialize()
	-- initialize our DB
	local defaults = {
		profile = {
			showCurrentSetIcon = true,
			showSetInTitle = false,
			showGearFuTitle = true,
			iconSize = 24,
			colors = {
				title = {
					set = {
						r = 1,
						g = 1,
						b = 1,
						a = 1
					}	-- white
				},
				tooltip = {
					set = {
						r = 1,
						g = 1,
						b = 1,
						a = 1
					},	-- white
					selected  = {
						r = 1,
						g = 1,
						b = 0,
						a = 1
					}	-- yellow
				},
				chat = {
					default = {
						r = 1,
						g = 1,
						b = 1,
						a = 1
					},	-- white
					set = {
						r = 0,
						g = 1,
						b = 0,
						a = 1
					}	-- white		-- green
				}
			}
		}
	}
	self.db = LibStub('AceDB-3.0'):New('FuBar_GearFuDB', defaults, true);
	
	-- just to make sure
	self.db:SetProfile(self.db:GetCurrentProfile());

	
	-- initialize our config table (for AceConfig)
	self.options = {
		type = 'group',
		name = L["GearFu"],
		desc = L["Equipment Manager ++"],
		handler = GearFu,
		args = {
			general = {
				name = L["General"],
				desc = L["General options desc"],
				type = 'group',
				childGroups = 'tab',
				args = {
					gearfu = {
						name = L["GearFu"],
						desc = L["GearFu"],
						type = 'group',
						order = 1,
						args = {
							linebreak1 = {
								name = L['Tooltip options'],
								type = 'header',
								order = 1
							},
							iconsize = {
								name = L["Icon Size"],
								desc = L["What size the set-icon should be"],
								type = 'range',
								get = function(info)
									return GearFu.db.profile.iconSize
								end,
								set = function(info, value)
									GearFu.db.profile.iconSize = value
								end,
								min = 8,
								max = 32,
								step = 1,
								order = 2,
							},
							linebreak2 = {
								name = L['Title options'],
								type = 'header',
								order = 5
							},
							showsetintitle = {
								name = L["Set in title"],
								desc = L["Show the set name in the FuBar title"],
								type = 'toggle',
								get = function(info)
									return GearFu.db.profile.showSetInTitle
								end,
								set = function(info, value)
									GearFu.db.profile.showSetInTitle = value
									GearFu:updateTitle();
								end,
								disabled = function()
									return not GearFu.db.profile.showGearFuTitle;
								end,
								order = 6
							},
							showiconintitle = {
								name = L["Set-icon in title"],
								desc = L["Show the set-icon in title"],
								type = 'toggle',
								disabled = function()
									return (not GearFu.db.profile.showSetInTitle)
								end,
								get = function(info)
									return GearFu.db.profile.showCurrentSetIcon
								end,
								set = function(info, value)
									GearFu.db.profile.showCurrentSetIcon = value
									GearFu:updateTitle();
								end,
								order = 7
							},
							showgearfuintitle = {
								name = L["Show addon name in title"],
								desc = L["Show the addon name in the FuBar title. Either this, the set, or both must be shown."],
								type = 'toggle',
								disabled = function()
									return (not GearFu.db.profile.showSetInTitle)
								end,
								get = function()
									return GearFu.db.profile.showGearFuTitle
								end,
								set = function(info, val)
									GearFu.db.profile.showGearFuTitle = val;
									GearFu:updateTitle();
								end,
								order = 8
							}
						},
					},
					fubar = {
						name = L["FuBar"],
						desc = L['FuBar related options'],
						type = 'group',
						order = 2,
						args = {
							position = {
								type = 'select',
								name = L['Position on FuBar'],
								desc = L['Where the addon should be position on FuBar'],
								values = {
									LEFT = L['Left'],
									CENTER = L['Center'],
									RIGHT = L['Right']
								},
								style = 'radio',
								get = function()
									return GearFu:GetPanel() and GearFu:GetPanel():GetPluginSide(GearFu)
								end,
								set = function(info, value)
									if GearFu:GetPanel() then
										GearFu:GetPanel():SetPluginSide(GearFu, value)
									end
								end,
								order = 1,
							},
							colorText = {
								type = 'toggle',
								name = L['Show colored FuBar text'],
								desc = L['Show colored text in the FuBar title'],
								set = function() GearFu:ToggleFuBarTextColored() end,
								get = function() return GearFu:IsFuBarTextColored() end,
								order = 2,
							},
							detachTooltip = {
								type = 'toggle',
								name = L['Detach FuBar tooltip'],
								desc = L['Detach the GearFu tooltip from FuBar'],
								get = function() return GearFu:IsFuBarTooltipDetached() end,
								set = function() GearFu:ToggleFuBarTooltipDetached() end,
								order = 3,
							},
						}
					}
				},
				order = 1,
			},
			colors = {
				name = L["Colors"],
				desc = L["Text coloring"],
				type = 'group',
				childGroups = 'tab',
				order = 2,
				args = {
					title = {
						name = L["Title"],
						desc = L["FuBar title"],
						type = 'group',
						order = 1,
						args = {
							setname = {
								name = L["Set name"],
								desc = '',
								type = 'color',
								hasAlpha = true,
								get = function(info)
									return GearFu.db.profile.colors.title.set.r, GearFu.db.profile.colors.title.set.g, GearFu.db.profile.colors.title.set.b, GearFu.db.profile.colors.title.set.a;
								end,
								set = function(info,r,g,b,a)
									GearFu.db.profile.colors.title.set = {r=r,g=g,b=b,a=a};
								end,
								order = 1
							}
						}
					},
					tooltip = {
						name = L["Tooltip"],
						desc = '',
						type = 'group',
						order = 2,
						args = {
							setname = {
								name = L["Set name"],
								desc = '',
								type = 'color',
								hasAlpha = false,
								get = function(info)
									return GearFu.db.profile.colors.tooltip.set.r, GearFu.db.profile.colors.tooltip.set.g, GearFu.db.profile.colors.tooltip.set.b, GearFu.db.profile.colors.tooltip.set.a;
								end,
								set = function(info,r,g,b,a)
									GearFu.db.profile.colors.tooltip.set = {r=r,g=g,b=b,a=a}
								end,
								order = 1
							},
							selectedset = {
								name = L["Selected set"],
								desc = L["Name for the currently worn set"],
								type = 'color',
								hasAlpha = false,
								get = function(info)
									return GearFu.db.profile.colors.tooltip.selected.r, GearFu.db.profile.colors.tooltip.selected.g, GearFu.db.profile.colors.tooltip.selected.b, GearFu.db.profile.colors.tooltip.selected.a;
								end,
								set = function(info,r,g,b,a)
									GearFu.db.profile.colors.tooltip.selected = {r=r,g=g,b=b,a=a}
								end,
								order = 2
							}
						}
					},
					chat = {
						name = L["Chat"],
						desc = L["Colors used by GearFu in chatmessages"],
						type = 'group',
						order = 3,
						args = {
							setname = {
								name = L["Set name"],
								desc = '',
								hasAlpha = true,
								type = 'color',
								get = function(info)
									return GearFu.db.profile.colors.chat.set.r, GearFu.db.profile.colors.chat.set.g, GearFu.db.profile.colors.chat.set.b, GearFu.db.profile.colors.chat.set.a;
								end,
								set = function(info,r,g,b,a)
									GearFu.db.profile.colors.chat.set = {r=r,g=g,b=b,a=a}
								end,
								order = 2,
							},
							default = {
								name = L["Default color"],
								desc = L["Default color used by GearFu in chat"],
								type = 'color',
								hasAlpha = true,
								get = function(info)
									return GearFu.db.profile.colors.chat.default.r, GearFu.db.profile.colors.chat.default.g, GearFu.db.profile.colors.chat.default.b, GearFu.db.profile.colors.chat.default.a;
								end,
								set = function(info,r,g,b,a)
									GearFu.db.profile.colors.chat.default = {r=r,g=g,b=b,a=a}
								end,
								order = 1
							}
						}
					}
				}
			},
			profiles = LibStub('AceDBOptions-3.0'):GetOptionsTable(self.db),
		}
	}
	LibStub('AceConfig-3.0'):RegisterOptionsTable('FuBar_GearFu', self.options);
	
	-- let's also try to add this to the blizzard options
	LibStub('AceConfig-3.0'):RegisterOptionsTable("GearFu_Bliz", {
		name = L["GearFu"],
		handler = GearFu,
		type = 'group',
		args = {
			config = {
				name = L["Standalone config"],
				desc = L["Open a standlone config window, allowing you to configure GearFu."],
				type = 'execute',
				func = function()
					LibStub('AceConfigDialog-3.0'):Open('FuBar_GearFu')
				end
			}
		},
	})
	LibStub('AceConfigDialog-3.0'):AddToBlizOptions("GearFu_Bliz", L['GearFu'])
	
	
	-- index/scan various basic things
	self:reIndexSets();
	self:rescanCurrentSet();
	self:updateTitle();
	
	-- register our events
	self:RegisterEvent('UNIT_INVENTORY_CHANGED');
	self:RegisterEvent('WEAR_EQUIPMENT_SET');
	self:RegisterEvent('EQUIPMENT_SETS_CHANGED');
end;

function GearFu:RGB2Hex(set)
	local r = (set.r * 255);
	local g = (set.g * 255);
	local b = (set.b * 255);
	local a = (set.a * 255);
	
	return string.format("%02x%02x%02x%02x", a, r, g, b)
end


function GearFu:UNIT_INVENTORY_CHANGED(event, unitId)
	if unitId == 'player' then
		self:rescanCurrentSet();
	end;
end;

function GearFu:WEAR_EQUIPMENT_SET(event, setName)
	self.currentSet = self:getSetIdByName(setName);
end;

function GearFu:EQUIPMENT_SETS_CHANGED(event)
	self:reIndexSets();
	
	-- also check if the current set changed, we might have saved a new one
	self:rescanCurrentSet();
end;


function GearFu:getSetIdByName(name)
	for j = 1,GetNumEquipmentSets() do
		if GetEquipmentSetInfo(j) == name then
			return j;
		end;
	end;
	
	return -1;
end;

function GearFu:rescanCurrentSet() 
	-- try to figure out what set we're wearing now (if any)
	inventory = {};
	for i=0,19 do
		local link = GetInventoryItemLink('player', i);
		if link == nil then
			inventory[i] = 0;
		else
			local _, j = strsplit(':', link) 
			inventory[i] = tonumber(j, 10);
		end;
	end;
	
	local setFound = false;
	
	for i,set in pairs(self.sets) do
		local ids = GetEquipmentSetItemIDs(set.name);
		
		local f = true;
		for loc in pairs(inventory) do
			-- skip items that aren't saved for this set
			if ids[loc] then
				if not (tonumber(ids[loc]) == inventory[loc]) then
					f = false;
					break;
				end;
			end;
		end;
		if f then
			self.currentSet = i;
			setFound = true;
			break;
		end;
	end;
	
	if not setFound then
		self.currentSet = 0;
	end;

	-- update the title in case it changed
	self:updateTitle();
end;

-- for debug purposes only
function GearFu:dumpTbl(t, indent)
	local indtxt = '';
	if indent == nil then
		indent = 0;	
	else
		for i=1,indent do
			indtxt = indtxt..' ';
		end;
	end;
	if type(t) == 'table' then
		for k,v in pairs(t) do
			if type(v) == 'table' then
				DEFAULT_CHAT_FRAME:AddMessage(indtxt..'['..k..'] ('..type(v)..') = {')
				self:dumpTbl(v, indent+3);
				DEFAULT_CHAT_FRAME:AddMessage(indtxt..'}');
			else
				DEFAULT_CHAT_FRAME:AddMessage(indtxt..'['..k..'] ('..type(v)..') = '..v)
			end;
		end;
	else
		DEFAULT_CHAT_FRAME:AddMessage(indtxt..' ('..type(t)..') = '..t)
	end;
end;

function GearFu:OnUpdateFuBarTooltip()
	self:updateTitle();
	
	local cat = T:AddCategory(
        'columns', 1,
        'child_textR', 1,
        'child_textG', 1,
        'child_textB', 1,
        'child_justify', 'LEFT'
    )
    
    cat:AddLine();
	
	-- empty line to make it prettier
    cat:AddLine();
    
    -- make sure that the calendar is actually loaded, or else this won't work
	if (not GetCVar("equipmentManager") == 1) then
		cat:AddLine('EquipmentManager needs to be loaded for GearFu to function correctly. Go to Game Menu > Interface > Controls and make sure "Use Equipment manager" is ticked.', 1, 0, 0);
	end;
    
    -- Add list of events for today
    cat:AddLine("Your gear sets:", 'textR', 1, 'textG', 1, 'textB', 1);
    if (GetNumEquipmentSets() == 0) then
    	cat:AddLine(
		   'text', L["None"],
		   'indentation', 10,
		   'textR', 1, 'textG', 0, 'textB', 0
        )

    else
    	for i = 1, GetNumEquipmentSets() do
			local name, texture = GetEquipmentSetInfo(i);
			if self.currentSet == i then
				local c = self.db.profile.colors.tooltip.selected;
				cat:AddLine(
				   'text', '|T'..texture..':'..self.db.profile.iconSize..'|t '..name,
				   'indentation', 10,
				   'textR', c.r, 'textG', c.g, 'textB', c.b,
				   'func', function() GearFu:EquipSet(name) end
				);
			else
				local c = self.db.profile.colors.tooltip.set
				cat:AddLine(
				   'text', '|T'..texture..':'..self.db.profile.iconSize..'|t '..name,
				   'indentation', 10,
				   'textR', c.r, 'textG', c.g, 'textB', c.b,
				   'func', function() GearFu:EquipSet(name) end
				);
			end;
		end;
    end;
    
    cat:AddLine();
    
    T:SetHint(L['tooltip hint']);
end;

function GearFu:EquipSet(i) 
   -- is it even possible to switch sets now?
   if InCombatLockdown() then
   	DEFAULT_CHAT_FRAME:AddMessage('|cFF00FF00GearFu|r|cFFFF0000: You are unable to switch equipment currently. Switching sets has failed.|r');
   	return
   end;
   
	if GearFu.sets[i] then
		UseEquipmentSet(self.sets[i].name)
		name = self.sets[i].name;
		self.currentSet = i;
	else
		UseEquipmentSet(i)
		name = i;
		self.currentSet = self:getSetIdByName(name);
	end;
	
	DEFAULT_CHAT_FRAME:AddMessage('|cFF00FF00GearFu|r|c'..self:RGB2Hex(self.db.profile.colors.chat.default)..": Switched to set '|r|c"..self:RGB2Hex(self.db.profile.colors.chat.set)..name.."|r|c"..self:RGB2Hex(self.db.profile.colors.chat.default).."'|r");
	
	if self.sets[self.currentSet] == nil then
		-- might be an unloaded or new set, so let's reindex just in case
		self:reIndexSets();
	end;

	-- add set-name and icon to title (if configured)	
	self:updateTitle();
end;
